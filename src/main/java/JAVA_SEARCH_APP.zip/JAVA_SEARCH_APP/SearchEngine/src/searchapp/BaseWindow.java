package searchapp;

import java.awt.event.ActionListener;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JFrame;

public abstract class BaseWindow implements ActionListener{
//creates the absolute basic functionality every window will have
	public BaseWindow(){}
	public BaseWindow(String windowName, boolean setDecoration, Dimension windowSize){
		//this might remain empty for now
		initWindow( windowName,  setDecoration,  windowSize);
	}
	
	public void initWindow(String windowName, boolean setDecoration, Dimension windowSize){
		
	}
}
