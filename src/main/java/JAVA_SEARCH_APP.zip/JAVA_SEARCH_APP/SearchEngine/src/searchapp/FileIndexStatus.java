package searchapp;

public enum FileIndexStatus {
	INDEXED, OUTDATED
}
