package searchapp; 

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IndexSearch {
// for now this is an empty class, but will contain the algorithm to search for files
public static List<String> searchForText(String entry, SearchType searchtype){
//it is anticipated that this method will set the text of the search area in the main window
//as such it will return a string with newline characters based on what the algorithm computes
List<String> searchString = null;
System.out.println("starting search function");
System.out.println(searchtype);
//AND OPERATION
if(searchtype == SearchType.AND){
searchString = ANDOPERATION(entry);
}
//OR OPERATION
if(searchtype == SearchType.OR){
searchString = OROPERATION(entry);
}
//PHRASE OPERATION
if(searchtype == SearchType.PHRASE){
searchString = PHRASEOPERATION(entry);
}
System.out.println("search result: " + searchString);
return searchString;
}
//AND OPERATION METHOD
public static List<String> ANDOPERATION(String Entry){
    System.out.println("we are in the AND function");
    
String _delimiters = "[.?!:\\-=+,&()<>@#$%^\\*~` ]+";
String[] tokens = Entry.split(_delimiters);
boolean hasTokens = false;
List<String> result = new ArrayList<>();
for(File f: IndexModel.indexFileMap.keySet()){
    System.out.println(f.getPath());
for(String s: tokens){
if(IndexModel.indexFileMap.get(f).contains(s))
{
hasTokens = true;
continue;
}else{
hasTokens = false;
break;
}
}
if(hasTokens){result.add(f.getPath());}
}
return result;
}
//OR OPERATION METHOD
public static List<String> OROPERATION(String Entry){
System.out.println("we are in the OR function");
    
String _delimiters = "[.?!:\\-=+,&()<>@#$%^\\*~` ]+";
String[] tokens = Entry.split(_delimiters);
boolean hasTokens = false;
List<String> result = new ArrayList<>();
for(File f: IndexModel.indexFileMap.keySet()){
    System.out.println(f.getPath());
for(String s: tokens){
if(IndexModel.indexFileMap.get(f).contains(s))
{
System.out.println("file and string match:" + f.getPath() + s);
hasTokens = true;
continue;
}
}
if(hasTokens){result.add(f.getPath());}
}
return result;
}


//FIX-ME : PHRASE currently does not work beyond one word
//PHRASE OPERATION METHOD
public static List<String> PHRASEOPERATION(String Entry) {
    System.out.println("we are in the PHRASE function");
    
String _delimiters = "[.?!:\\-=+,&()<>@#$%^\\*~` ]+";
String[] tokens = Entry.split(_delimiters);
boolean hasTokens = false;
Integer index=null;
List<String> result = new ArrayList<>();

for(File f: IndexModel.indexFileMap.keySet())
{
    try{
    Scanner scanner = new Scanner(f);
    
    while(scanner.hasNextLine()){
        if(scanner.nextLine().contains(Entry)){
            //we have found the phrase in the file, add it to results and move on
            result.add(f.getPath());
            scanner.close();
            break;
        }
    }
    }catch(Exception e)
    {
        result.add("no luck...");
        return result;
    }
}

return result;}
//TODO create algorithm to search for files
}