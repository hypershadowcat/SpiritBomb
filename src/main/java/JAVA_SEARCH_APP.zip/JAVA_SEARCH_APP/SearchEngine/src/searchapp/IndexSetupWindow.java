package searchapp;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class IndexSetupWindow extends BaseWindow {
JFrame frame = new JFrame("Maintain index");
public IndexSetupWindow(){
initWindow();
JFrame frame;
JFrame.setDefaultLookAndFeelDecorated(true);
frame = new JFrame ("maintenance index");
}
///TODO
// Get the indexes visible in the JTable
//  save the last modification date to detect if outdated
//  get it so it detects deleted  files
//  save the index to a file so it can be accessed anytime
//  utilize an update method of some kind to check if the indexFileMap is valid
///

//this is what will be affected when inserting and removing data from the table
//it will be affected everytime there is a change to the indexFileStatus



public void initWindow() {
// TODO Auto-generated method stub
//initialize frame size
// make frame..
final JTextArea fileIndex= new JTextArea("");
fileIndex.setText(IndexModel.UpdateView());
   frame.setSize(700,700);
   frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
   frame.setBackground(Color.RED);
   frame.setBounds(600,460,400,600);
   frame.setLayout(new BorderLayout());
   //frame.setSize(200, 200);
   frame.setVisible(false);
   //create the panels
   JPanel buttonPanel = new JPanel();
   buttonPanel.setLayout(new FlowLayout());
   
   JPanel topLayout = new JPanel();
   topLayout.setLayout(new BorderLayout());
   
   //create the buttons to work with the maintenance window
   
   //add button
   JButton frm = new JButton("Add your File");     
  // frm.setBounds(334, 126, 90, 25);
   buttonPanel.add(frm);
   
   //Create a table to view files available in index

  
   
   frame.add(fileIndex,BorderLayout.CENTER);
   
   
   frm.addActionListener(new ActionListener () {
    @Override
    public void actionPerformed ( ActionEvent ae){
    SwingUtilities.invokeLater (new Runnable (){
    public void run (){
   
// TODO: Replace with JFile Chooser;
    JFileChooser chooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter(
       "Text Files", "txt");
    chooser.setFileFilter(filter);
    int returnVal = chooser.showOpenDialog(frame);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
   
   
    //this is where the file operation occurs to 
    //a) add the file to the list of indexes, set to indexed
   
    //b)it is rendered on the table as such
   
      System.out.println("You chose to open this file: " +
           chooser.getSelectedFile().getName());
      System.out.println("File to save: " + chooser.getSelectedFile());
     IndexModel.AddFile(chooser.getSelectedFile());
     
  fileIndex.setText("");
fileIndex.setText(IndexModel.UpdateView());
     
    }
    }
    });
    }
   });
   
   //rebuild button
   Button from = new Button("Rebuild");     
  // frm.setBounds(334, 126, 90, 25);
from.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent ae)
           {
               // Show the file chooser
              IndexModel.Rebuild();
              fileIndex.setText("");
              fileIndex.setText(IndexModel.UpdateView());
           }

       });

   buttonPanel.add(from);
   
   
 //remove button  
   Button fro = new Button("Remove");     

buttonPanel.add(fro);
   // frm.setBounds(334, 126, 90, 25);
fro.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent ae)
           {
              //prompt for file name
            String filename = JOptionPane.showInputDialog(null, "please enter the file name : ", 
            "Searchapp", 1);
            System.out.println(filename);
            if(filename != null){
            IndexModel.RemoveFile(filename);
            fileIndex.setText("");
            fileIndex.setText(IndexModel.UpdateView());
               }
           }

       });

       // Register the delete action
       registerDelAction();


   JLabel labelOptions = new JLabel("SEARCH ENGINE- MAINTENANCE");
       labelOptions.setBounds(220, 60, 250, 70);

       
  topLayout.add(labelOptions, BorderLayout.PAGE_START);
  topLayout.add(buttonPanel, BorderLayout.PAGE_END);
  frame.add(topLayout,BorderLayout.PAGE_START);
  
  //we will use this as the primary means to update the window
frame.addFocusListener(new FocusListener(){

@Override
public void focusGained(FocusEvent arg0) {
// TODO Auto-generated method stub
IndexModel.checkIfOutdated();
fileIndex.setText("");
fileIndex.setText(IndexModel.UpdateView());
}

@Override
public void focusLost(FocusEvent arg0) {
// TODO Auto-generated method stub
}
 
});
       
 
 
}
private void registerDelAction() {
// TODO Auto-generated method stub
}

public void setVisibility(boolean visibility){
frame.setVisible(visibility);
}

@Override
public void actionPerformed(ActionEvent e) {
// TODO Auto-generated method stub
}

}