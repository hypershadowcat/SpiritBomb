
package searchapp;


public class Main {


//this is the class that contains the main method, best for abstraction reasons   

 public static void main(String[] args) {
IndexModel.INITMODEL();
MainWindow mw = new MainWindow();
 

    }  
   

}
