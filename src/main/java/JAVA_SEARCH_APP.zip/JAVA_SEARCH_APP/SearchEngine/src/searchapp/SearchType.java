package searchapp;
//used to determine the type of searching done
public enum SearchType {
	AND, OR, PHRASE
}