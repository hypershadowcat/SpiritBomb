package searchapp;

import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

//the about window contains text describing who the authors of the program are

public class AboutWindow extends BaseWindow {
	JFrame frame = new JFrame("About us");
	
	
	
	public AboutWindow(){initWindow();}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}
	
	public void initWindow() {
		// TODO Auto-generated method stub
		//initialize frame size
				// make frame..
			    JFrame.setDefaultLookAndFeelDecorated(true);
			    
			    frame.setSize(400,400);
			    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
			    frame.setBackground(Color.RED);
			    frame.setBounds(100,90,300,120);
			    frame.setLayout(new FlowLayout());
			    //frame.setSize(200, 200);
			    frame.setVisible(false);
		
			    //TODO add the necessary components
			    
			    //creating the layout
			    Container content = frame.getContentPane();
			    GridBagConstraints gbc = new GridBagConstraints ();
			   Dimension buttonsize = new Dimension(100,25);  
			   Button about;
			   about = new Button("About");
			   about.setPreferredSize(buttonsize);
			    //add content
			    content.setLayout(new GridBagLayout());
			       content.setBackground(Color.red);
			       gbc.gridx = 0;
			       gbc.gridy = 0;
			       content.add(about,gbc);
			       
			       //this will cause the about us dialog to popup
			       about.addActionListener(new ActionListener(){
			             public void actionPerformed(ActionEvent ae){
			             JOptionPane.showMessageDialog(null, "Search Engine" + "-Project"
			            		                  +"-Written by Juliet Mercado Zachary Willis "
			            		                  + "Ihor Panchenko Craig Anderson", 
			            		                              "About", 1);
			             }
			             });
	}

	public void setVisibility(boolean visibility){
		frame.setVisible(visibility);
	}
	



}
