package searchapp;
//this helps determine the file status in the index maintenance window
public enum FileStatus {
	INDEXED, OUTDATED
}
