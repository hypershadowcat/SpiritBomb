/**
 * 
 */
package searchapp;
import searchapp.MainWindow;
/**

 *			
 */
public class Main {


	//this is the class that contains the main method, best for abstraction reasons   

 public static void main(String[] args) {

	 MainWindow mw = new MainWindow();
   

    }  
   

}

